/* ==========================================================
   SYLHET SATHKORA — app.js
   Vanilla JS: navbar scroll, mobile menu, animations, ripple
   ========================================================== */

(function () {
  'use strict';

  /* --------------------------------------------------------
     CONFIG — Order System (Google Apps Script integration)
     -------------------------------------------------------- */
  /*
    1. Deploy Code.gs as a Web App (see README.md for steps).
    2. Copy the deployment URL — it looks like:
       https://script.google.com/macros/s/AKfycb.../exec
    3. Paste it below, replacing the placeholder string.
  */
  var APPS_SCRIPT_URL = 'https://script.google.com/macros/s/YOUR_DEPLOYMENT_ID/exec';

  /* Business contact number used to build the WhatsApp order link */
  var WHATSAPP_NUMBER = '8801XXXXXXXXX'; /* digits only, country code first, no + or spaces */

  /* Request timeout (ms) — guards against a hung network call */
  var REQUEST_TIMEOUT_MS = 15000;


  /* --------------------------------------------------------
     UTILITIES
     -------------------------------------------------------- */
  function qs(selector, scope) {
    return (scope || document).querySelector(selector);
  }

  function qsa(selector, scope) {
    return Array.from((scope || document).querySelectorAll(selector));
  }

  /* Basic input sanitizer: trims whitespace and strips angle brackets
     to reduce the risk of markup/script injection reaching the sheet. */
  function sanitizeInput(value) {
    return String(value || '').trim().replace(/[<>]/g, '');
  }

  /* Detect a coarse device category from the user agent (best-effort only) */
  function detectDevice() {
    var ua = navigator.userAgent || '';
    if (/Mobi|Android/i.test(ua)) return 'Mobile';
    if (/Tablet|iPad/i.test(ua)) return 'Tablet';
    return 'Desktop';
  }

  /* Detect a coarse browser name from the user agent (best-effort only) */
  function detectBrowser() {
    var ua = navigator.userAgent || '';
    if (ua.indexOf('Edg/') > -1) return 'Edge';
    if (ua.indexOf('Chrome') > -1) return 'Chrome';
    if (ua.indexOf('Firefox') > -1) return 'Firefox';
    if (ua.indexOf('Safari') > -1) return 'Safari';
    return 'Other';
  }

  /* Generates a client-side fallback Order ID (SS + timestamp-based number).
     The Apps Script also generates its own sequential ID (SS1001, SS1002…)
     from the sheet's row count; this fallback is only used if the server
     response doesn't include one (e.g. offline demo mode). */
  function generateOrderID() {
    var stored = parseInt(localStorage.getItem('ss_last_order_seq') || '1000', 10);
    var next = stored + 1;
    try { localStorage.setItem('ss_last_order_seq', String(next)); } catch (e) { /* ignore quota errors */ }
    return 'SS' + next;
  }


  /* --------------------------------------------------------
     1. NAVBAR — scroll detection
     -------------------------------------------------------- */
  (function initNavbar() {
    const navbar = qs('#navbar');
    if (!navbar) return;

    const SCROLL_THRESHOLD = 48;

    function handleScroll() {
      if (window.scrollY > SCROLL_THRESHOLD) {
        navbar.classList.add('is-scrolled');
      } else {
        navbar.classList.remove('is-scrolled');
      }
    }

    // Throttle scroll handler for performance
    let ticking = false;
    window.addEventListener('scroll', function () {
      if (!ticking) {
        window.requestAnimationFrame(function () {
          handleScroll();
          ticking = false;
        });
        ticking = true;
      }
    }, { passive: true });

    // Check on load in case user refreshed mid-page
    handleScroll();
  })();


  /* --------------------------------------------------------
     2. MOBILE MENU — hamburger toggle
     -------------------------------------------------------- */
  (function initMobileMenu() {
    const hamburger = qs('#hamburgerBtn');
    const menu      = qs('#mobileMenu');
    const overlay   = qs('#overlay');
    const body      = document.body;

    if (!hamburger || !menu || !overlay) return;

    const mobileLinks = qsa('.mobile-menu__link', menu);

    function openMenu() {
      hamburger.setAttribute('aria-expanded', 'true');
      menu.classList.add('is-open');
      menu.setAttribute('aria-hidden', 'false');
      overlay.classList.add('is-visible');
      overlay.setAttribute('aria-hidden', 'false');
      body.style.overflow = 'hidden';

      // Enable tabbing into menu links
      mobileLinks.forEach(function (link) {
        link.setAttribute('tabindex', '0');
      });

      const menuCta = qs('.mobile-menu__cta', menu);
      if (menuCta) menuCta.setAttribute('tabindex', '0');

      // Focus first link for keyboard users
      if (mobileLinks.length) mobileLinks[0].focus();
    }

    function closeMenu() {
      hamburger.setAttribute('aria-expanded', 'false');
      menu.classList.remove('is-open');
      menu.setAttribute('aria-hidden', 'true');
      overlay.classList.remove('is-visible');
      overlay.setAttribute('aria-hidden', 'true');
      body.style.overflow = '';

      // Disable tabbing into hidden menu links
      mobileLinks.forEach(function (link) {
        link.setAttribute('tabindex', '-1');
      });

      const menuCta = qs('.mobile-menu__cta', menu);
      if (menuCta) menuCta.setAttribute('tabindex', '-1');

      hamburger.focus();
    }

    hamburger.addEventListener('click', function () {
      const isOpen = hamburger.getAttribute('aria-expanded') === 'true';
      if (isOpen) closeMenu();
      else openMenu();
    });

    overlay.addEventListener('click', closeMenu);

    // Close menu when a nav link is clicked
    mobileLinks.forEach(function (link) {
      link.addEventListener('click', closeMenu);
    });

    const menuCta = qs('.mobile-menu__cta', menu);
    if (menuCta) {
      menuCta.addEventListener('click', closeMenu);
    }

    // Close on Escape key
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && hamburger.getAttribute('aria-expanded') === 'true') {
        closeMenu();
      }
    });

    // Trap focus within mobile menu when open
    menu.addEventListener('keydown', function (e) {
      if (e.key !== 'Tab') return;

      const focusable = qsa(
        'a[tabindex="0"], button[tabindex="0"]',
        menu
      );

      if (!focusable.length) return;

      const first = focusable[0];
      const last  = focusable[focusable.length - 1];

      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    });
  })();


  /* --------------------------------------------------------
     3. SCROLL ANIMATIONS — fade-up on page load
     -------------------------------------------------------- */
  (function initAnimations() {
    const targets = qsa('[data-animate="fade-up"]');
    if (!targets.length) return;

    // Use Intersection Observer for scroll-triggered animations
    const observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, {
      threshold: 0.12,
      rootMargin: '0px 0px -40px 0px'
    });

    targets.forEach(function (el) {
      observer.observe(el);
    });

    // Trigger hero elements with a short delay on first load
    // to ensure the page renders first
    window.addEventListener('load', function () {
      setTimeout(function () {
        targets.forEach(function (el) {
          // Trigger any visible elements immediately
          const rect = el.getBoundingClientRect();
          if (rect.top < window.innerHeight) {
            el.classList.add('is-visible');
          }
        });
      }, 80);
    });
  })();


  /* --------------------------------------------------------
     4. BUTTON RIPPLE EFFECT
     -------------------------------------------------------- */
  (function initRipple() {
    const buttons = qsa('.btn');

    buttons.forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        const ripple = document.createElement('span');
        ripple.className = 'btn__ripple';

        const rect     = btn.getBoundingClientRect();
        const size     = Math.max(rect.width, rect.height) * 1.8;
        const x        = e.clientX - rect.left - size / 2;
        const y        = e.clientY - rect.top  - size / 2;

        ripple.style.cssText = [
          'width:'  + size + 'px',
          'height:' + size + 'px',
          'left:'   + x    + 'px',
          'top:'    + y    + 'px'
        ].join(';');

        btn.appendChild(ripple);

        ripple.addEventListener('animationend', function () {
          ripple.remove();
        });
      });
    });
  })();


  /* --------------------------------------------------------
     5. SMOOTH SCROLL for anchor links
     -------------------------------------------------------- */
  (function initSmoothScroll() {
    const NAVBAR_H = parseInt(
      getComputedStyle(document.documentElement)
        .getPropertyValue('--navbar-h') || '72',
      10
    );

    document.addEventListener('click', function (e) {
      const anchor = e.target.closest('a[href^="#"]');
      if (!anchor) return;

      const targetId = anchor.getAttribute('href').slice(1);
      if (!targetId) return;

      const target = document.getElementById(targetId);
      if (!target) return;

      e.preventDefault();

      const top = target.getBoundingClientRect().top + window.scrollY - NAVBAR_H - 16;

      window.scrollTo({ top: top, behavior: 'smooth' });
    });
  })();


  /* --------------------------------------------------------
     6. ACTIVE NAV LINK on scroll (Intersection Observer)
     -------------------------------------------------------- */
  (function initActiveNav() {
    const sections = qsa('section[id], div[id]');
    const navLinks = qsa('.navbar__link');

    if (!sections.length || !navLinks.length) return;

    const observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;

        navLinks.forEach(function (link) {
          link.removeAttribute('aria-current');
          if (link.getAttribute('href') === '#' + entry.target.id) {
            link.setAttribute('aria-current', 'page');
          }
        });
      });
    }, {
      rootMargin: '-40% 0px -55% 0px'
    });

    sections.forEach(function (section) {
      observer.observe(section);
    });
  })();


  /* ========================================================
     PART 2 — Package selection, Order form, Validation
     ======================================================== */

  /* --------------------------------------------------------
     7. PACKAGE CARDS — selection, summary sync, scroll
     -------------------------------------------------------- */
  (function initPackages() {
    var cards       = qsa('.pkg-card');
    var pkgSelect   = qs('#fieldPackage');
    var summaryEmoji = qs('#summaryEmoji');
    var summaryName  = qs('#summaryName');
    var summaryPrice = qs('#summaryPrice');
    var summaryTotal = qs('#summaryTotal');

    if (!cards.length) return;

    /* Select a package by pkg-id */
    function selectPackage(pkgId) {
      /* Update card highlight */
      cards.forEach(function (c) {
        var isThis = c.dataset.pkgId === pkgId;
        c.classList.toggle('is-selected', isThis);
        /* Swap button variant */
        var btn = c.querySelector('.pkg-card__btn');
        if (!btn) return;
        if (isThis) {
          btn.classList.add('btn--primary');
          btn.classList.remove('btn--ghost');
        } else {
          /* Featured card defaults to primary, others to ghost */
          if (c.classList.contains('pkg-card--featured')) {
            btn.classList.add('btn--primary');
            btn.classList.remove('btn--ghost');
          } else {
            btn.classList.add('btn--ghost');
            btn.classList.remove('btn--primary');
          }
        }
      });

      /* Update dropdown */
      if (pkgSelect) {
        pkgSelect.value = pkgId;
        pkgSelect.dispatchEvent(new Event('change'));
      }

      /* Update summary */
      var card = cards.find(function (c) { return c.dataset.pkgId === pkgId; });
      if (card && summaryEmoji && summaryName && summaryPrice && summaryTotal) {
        summaryEmoji.textContent = card.dataset.pkgEmoji || '🍋';
        summaryName.textContent  = card.dataset.pkgName  || '';
        var price = card.dataset.pkgPrice || '0';
        summaryPrice.textContent = '৳' + parseInt(price, 10).toLocaleString('en-BD');
        summaryTotal.textContent = '৳' + parseInt(price, 10).toLocaleString('en-BD');
      }
    }

    /* Card click / keyboard */
    cards.forEach(function (card) {
      function handleSelect(e) {
        /* Don't double-fire if the button itself triggered this */
        var btn = card.querySelector('.pkg-card__btn');
        if (e.target === btn || btn && btn.contains(e.target)) return;
        selectPackage(card.dataset.pkgId);
        scrollToOrder();
      }

      card.addEventListener('click', handleSelect);
      card.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          selectPackage(card.dataset.pkgId);
          scrollToOrder();
        }
      });

      /* Button inside card */
      var btn = card.querySelector('.pkg-card__btn');
      if (btn) {
        btn.addEventListener('click', function (e) {
          e.stopPropagation();
          selectPackage(card.dataset.pkgId);
          scrollToOrder();
        });
      }
    });

    /* Dropdown change syncs summary */
    if (pkgSelect) {
      pkgSelect.addEventListener('change', function () {
        var selectedId = pkgSelect.value;
        if (!selectedId) return;
        var matchCard = cards.find(function (c) { return c.dataset.pkgId === selectedId; });
        if (!matchCard) return;
        /* Update summary without re-triggering scroll */
        cards.forEach(function (c) {
          c.classList.toggle('is-selected', c.dataset.pkgId === selectedId);
          var b = c.querySelector('.pkg-card__btn');
          if (!b) return;
          if (c.dataset.pkgId === selectedId) {
            b.classList.add('btn--primary'); b.classList.remove('btn--ghost');
          } else {
            if (c.classList.contains('pkg-card--featured')) {
              b.classList.add('btn--primary'); b.classList.remove('btn--ghost');
            } else {
              b.classList.add('btn--ghost'); b.classList.remove('btn--primary');
            }
          }
        });
        if (summaryEmoji) summaryEmoji.textContent = matchCard.dataset.pkgEmoji || '🍋';
        if (summaryName)  summaryName.textContent  = matchCard.dataset.pkgName  || '';
        var price = matchCard.dataset.pkgPrice || '0';
        if (summaryPrice) summaryPrice.textContent = '৳' + parseInt(price, 10).toLocaleString('en-BD');
        if (summaryTotal) summaryTotal.textContent = '৳' + parseInt(price, 10).toLocaleString('en-BD');
      });
    }

    function scrollToOrder() {
      var orderSection = qs('#order');
      if (!orderSection) return;
      var navbarH = parseInt(
        getComputedStyle(document.documentElement).getPropertyValue('--navbar-h') || '72',
        10
      );
      var top = orderSection.getBoundingClientRect().top + window.scrollY - navbarH - 24;
      window.scrollTo({ top: top, behavior: 'smooth' });
    }
  })();


  /* --------------------------------------------------------
     8. ORDER FORM — validation & submission
     -------------------------------------------------------- */
  (function initOrderForm() {
    var form         = qs('#orderForm');
    var submitBtn    = qs('#placeOrderBtn');
    var successBox   = qs('#orderSuccess');
    var pkgSelect    = qs('#fieldPackage');

    if (!form) return;

    /* BD phone: starts with 01, then 3–9, then 8 more digits = 11 digits total */
    var BD_PHONE_RE = /^(?:\+88)?01[3-9]\d{8}$/;

    /* Validation rules per field id */
    var rules = {
      fieldName:     { required: true, label: 'Full name' },
      fieldPhone:    { required: true, label: 'Phone number', pattern: BD_PHONE_RE, patternMsg: 'Enter a valid Bangladeshi number (e.g. 01712345678)' },
      fieldAddress:  { required: true, label: 'Delivery address' },
      fieldDistrict: { required: true, label: 'District' },
      fieldUpazila:  { required: true, label: 'Upazila' }
    };

    var isSubmitting = false; /* guards against duplicate/double-click submission */

    function showError(fieldId, msg) {
      var input = qs('#' + fieldId);
      var errEl = qs('#' + fieldId + '-err');
      if (!input || !errEl) return;
      input.classList.add('is-error');
      errEl.textContent = msg;
    }

    function clearError(fieldId) {
      var input = qs('#' + fieldId);
      var errEl = qs('#' + fieldId + '-err');
      if (!input || !errEl) return;
      input.classList.remove('is-error');
      errEl.textContent = '';
    }

    function validateField(fieldId) {
      var rule  = rules[fieldId];
      var input = qs('#' + fieldId);
      if (!rule || !input) return true;

      var val = input.value.trim();

      if (rule.required && !val) {
        showError(fieldId, rule.label + ' is required.');
        return false;
      }
      if (rule.pattern && val && !rule.pattern.test(val)) {
        showError(fieldId, rule.patternMsg || 'Invalid format.');
        return false;
      }
      clearError(fieldId);
      return true;
    }

    /* validateForm(): validates every rule plus package/payment selection.
       Returns true only if the whole order form is ready to submit. */
    function validateForm() {
      var valid = true;

      Object.keys(rules).forEach(function (id) {
        if (!validateField(id)) valid = false;
      });

      if (pkgSelect && !pkgSelect.value) {
        valid = false;
        pkgSelect.classList.add('is-error');
      } else if (pkgSelect) {
        pkgSelect.classList.remove('is-error');
      }

      var paymentChecked = form.querySelector('input[name="payment"]:checked');
      if (!paymentChecked) valid = false;

      return valid;
    }

    /* Live validation on blur */
    Object.keys(rules).forEach(function (id) {
      var input = qs('#' + id);
      if (!input) return;
      input.addEventListener('blur', function () { validateField(id); });
      input.addEventListener('input', function () {
        if (input.classList.contains('is-error')) clearError(id);
      });
    });

    if (pkgSelect) {
      pkgSelect.addEventListener('change', function () {
        pkgSelect.classList.remove('is-error');
      });
    }

    /* Builds the payload sent to the Apps Script Web App */
    function buildOrderPayload() {
      var packageSelect = qs('#fieldPackage');
      var selectedOption = packageSelect ? packageSelect.options[packageSelect.selectedIndex] : null;
      var packageLabel = selectedOption ? selectedOption.textContent.trim() : '';
      var price = selectedOption ? (selectedOption.dataset.price || '0') : '0';
      var qtyMatch = packageSelect && packageSelect.value ? packageSelect.value : '1';

      var paymentInput = form.querySelector('input[name="payment"]:checked');
      var paymentValue = paymentInput ? paymentInput.value : '';
      var paymentLabelMap = { bkash: 'bKash', nagad: 'Nagad', cod: 'Cash on Delivery' };

      return {
        customerName:  sanitizeInput(qs('#fieldName').value),
        phone:         sanitizeInput(qs('#fieldPhone').value),
        address:       sanitizeInput(qs('#fieldAddress').value),
        district:      sanitizeInput(qs('#fieldDistrict').value),
        upazila:       sanitizeInput(qs('#fieldUpazila').value),
        package:       packageLabel,
        quantity:      qtyMatch,
        price:         price,
        paymentMethod: paymentLabelMap[paymentValue] || paymentValue,
        orderNote:     sanitizeInput(qs('#fieldNotes') ? qs('#fieldNotes').value : ''),
        device:        detectDevice(),
        browser:       detectBrowser()
      };
    }

    /* submitOrder(): POSTs the payload to the Apps Script Web App with a
       timeout guard. Resolves with the parsed JSON response, or rejects
       with an Error describing the failure (timeout / network / server). */
    function submitOrder(payload) {
      return new Promise(function (resolve, reject) {
        if (!APPS_SCRIPT_URL || APPS_SCRIPT_URL.indexOf('YOUR_DEPLOYMENT_ID') > -1) {
          reject(new Error('CONFIG_MISSING'));
          return;
        }

        var controller = (typeof AbortController !== 'undefined') ? new AbortController() : null;
        var timeoutId = setTimeout(function () {
          if (controller) controller.abort();
        }, REQUEST_TIMEOUT_MS);

        fetch(APPS_SCRIPT_URL, {
          method: 'POST',
          /* text/plain avoids a CORS preflight against Apps Script, which
             only handles simple POST requests without OPTIONS support. */
          headers: { 'Content-Type': 'text/plain;charset=utf-8' },
          body: JSON.stringify(payload),
          signal: controller ? controller.signal : undefined
        })
          .then(function (res) {
            clearTimeout(timeoutId);
            if (!res.ok) throw new Error('SERVER_ERROR');
            return res.json();
          })
          .then(function (data) {
            if (!data || data.status !== 'success') {
              reject(new Error(data && data.message ? data.message : 'SERVER_ERROR'));
              return;
            }
            resolve(data);
          })
          .catch(function (err) {
            clearTimeout(timeoutId);
            if (err && err.name === 'AbortError') {
              reject(new Error('TIMEOUT'));
            } else {
              reject(new Error('NETWORK_ERROR'));
            }
          });
      });
    }

    function buildWhatsAppLink(orderId, payload) {
      var lines = [
        'Hello! I would like to confirm my order:',
        '',
        'Order ID: ' + orderId,
        'Name: ' + payload.customerName,
        'Package: ' + payload.package,
        'Price: ৳' + payload.price,
        'Payment: ' + payload.paymentMethod,
        'Phone: ' + payload.phone,
        'Address: ' + payload.address + ', ' + payload.upazila + ', ' + payload.district
      ];
      var text = encodeURIComponent(lines.join('\n'));
      return 'https://wa.me/' + WHATSAPP_NUMBER + '?text=' + text;
    }

    /* Form submit */
    form.addEventListener('submit', function (e) {
      e.preventDefault();

      if (isSubmitting) return; /* prevent duplicate submission */

      if (!validateForm()) {
        var firstErr = form.querySelector('.is-error');
        if (firstErr) firstErr.focus();
        return;
      }

      var payload = buildOrderPayload();

      isSubmitting = true;
      if (submitBtn) submitBtn.disabled = true;
      showLoading('Placing your order…');

      submitOrder(payload)
        .then(function (response) {
          hideLoading();
          isSubmitting = false;
          if (submitBtn) submitBtn.disabled = false;

          var orderId = response.orderId || generateOrderID();

          if (successBox) {
            successBox.hidden = false;
          }

          showSuccessPopup(orderId, payload);

          resetForm();
        })
        .catch(function (err) {
          hideLoading();
          isSubmitting = false;
          if (submitBtn) submitBtn.disabled = false;
          showErrorPopup(mapErrorMessage(err));
        });
    });

    /* Maps an internal error code/message to a friendly popup message */
    function mapErrorMessage(err) {
      var msg = err && err.message ? err.message : '';
      if (msg === 'CONFIG_MISSING') {
        return 'Ordering isn\u2019t fully set up yet \u2014 the store owner needs to connect the Google Sheet. Please try Cash on Delivery via WhatsApp instead.';
      }
      if (msg === 'TIMEOUT') {
        return 'The request took too long to respond. Please check your internet connection and try again.';
      }
      if (msg === 'NETWORK_ERROR') {
        return 'We couldn\u2019t reach the server. Please check your internet connection and try again.';
      }
      if (msg === 'SERVER_ERROR') {
        return 'Our server had trouble processing your order. Please try again in a moment.';
      }
      return msg || 'Something went wrong. Please try again.';
    }

    function showErrorPopup(message) {
      var errorModal = qs('#errorModal');
      var errorText  = qs('#errorModalText');
      if (!errorModal) return;
      if (errorText) errorText.textContent = message;
      openModal(errorModal);
    }

    function showSuccessPopup(orderId, payload) {
      var successModal  = qs('#successModal');
      var orderIdBox     = qs('#successOrderId');
      var whatsappBtn    = qs('#successWhatsappBtn');
      if (!successModal) return;

      if (orderIdBox) orderIdBox.textContent = 'Order ID: ' + orderId;
      if (whatsappBtn) whatsappBtn.setAttribute('href', buildWhatsAppLink(orderId, payload));

      openModal(successModal);

      /* Populate and reveal the Thank You section in the background */
      var thankYou       = qs('#thankYou');
      var thankYouOrderId = qs('#thankYouOrderId');
      if (thankYou) {
        thankYou.hidden = false;
        if (thankYouOrderId) thankYouOrderId.textContent = 'Order ID: ' + orderId;
      }
    }

    /* resetForm(): clears the native form fields, the order summary
       sidebar, and any package-card selection highlight — used after
       a successful submission so the form is ready for a new order. */
    function resetForm() {
      form.reset();
      resetSummary();
      resetCards();
    }

    function resetSummary() {
      var summaryEmoji = qs('#summaryEmoji');
      var summaryName  = qs('#summaryName');
      var summaryPrice = qs('#summaryPrice');
      var summaryTotal = qs('#summaryTotal');
      if (summaryEmoji) summaryEmoji.textContent = '🍋';
      if (summaryName)  summaryName.textContent  = 'Select a package';
      if (summaryPrice) summaryPrice.textContent = '—';
      if (summaryTotal) summaryTotal.textContent = '—';
    }

    function resetCards() {
      qsa('.pkg-card').forEach(function (card) {
        card.classList.remove('is-selected');
        var btn = card.querySelector('.pkg-card__btn');
        if (!btn) return;
        if (card.classList.contains('pkg-card--featured')) {
          btn.classList.add('btn--primary');
          btn.classList.remove('btn--ghost');
        } else {
          btn.classList.add('btn--ghost');
          btn.classList.remove('btn--primary');
        }
      });
    }
  })();


  /* --------------------------------------------------------
     LOADING OVERLAY — showLoading() / hideLoading()
     -------------------------------------------------------- */
  function showLoading(message) {
    var overlay = qs('#loadingOverlay');
    var text    = qs('.loading-overlay__text', overlay);
    if (!overlay) return;
    if (text && message) text.textContent = message;
    overlay.hidden = false;
    document.body.classList.add('is-loading');
  }

  function hideLoading() {
    var overlay = qs('#loadingOverlay');
    if (!overlay) return;
    overlay.hidden = true;
    document.body.classList.remove('is-loading');
  }


  /* --------------------------------------------------------
     MODAL HELPERS — shared by Success & Error popups
     -------------------------------------------------------- */
  function openModal(modalEl) {
    if (!modalEl) return;
    modalEl.hidden = false;
    modalEl.setAttribute('aria-hidden', 'false');
    document.body.classList.add('is-loading'); /* reuse scroll lock */

    var closeBtn = modalEl.querySelector('.modal__close');
    if (closeBtn) closeBtn.focus();
  }

  function closeModal(modalEl) {
    if (!modalEl) return;
    modalEl.hidden = true;
    modalEl.setAttribute('aria-hidden', 'true');
    /* Only unlock scroll if no other overlay/modal is open */
    var anyOpen = qsa('.modal:not([hidden]), .loading-overlay:not([hidden])').length > 0;
    if (!anyOpen) document.body.classList.remove('is-loading');
  }

  (function initModals() {
    var successModal  = qs('#successModal');
    var errorModal     = qs('#errorModal');

    /* Success modal controls */
    if (successModal) {
      var successClose    = qs('#successModalClose');
      var successBackdrop = qs('#successModalBackdrop');
      var continueBtn     = qs('#successContinueBtn');

      if (successClose)    successClose.addEventListener('click', function () { closeModal(successModal); });
      if (successBackdrop) successBackdrop.addEventListener('click', function () { closeModal(successModal); });
      if (continueBtn) {
        continueBtn.addEventListener('click', function () {
          closeModal(successModal);
          var thankYou = qs('#thankYou');
          if (thankYou && !thankYou.hidden) {
            thankYou.scrollIntoView({ behavior: 'smooth', block: 'start' });
          }
        });
      }
    }

    /* Error modal controls */
    if (errorModal) {
      var errorClose    = qs('#errorModalClose');
      var errorBackdrop = qs('#errorModalBackdrop');
      var retryBtn       = qs('#errorRetryBtn');

      if (errorClose)    errorClose.addEventListener('click', function () { closeModal(errorModal); });
      if (errorBackdrop) errorBackdrop.addEventListener('click', function () { closeModal(errorModal); });
      if (retryBtn) {
        retryBtn.addEventListener('click', function () {
          closeModal(errorModal);
          var submitBtn = qs('#placeOrderBtn');
          if (submitBtn) submitBtn.click();
        });
      }
    }

    /* Escape key closes whichever modal is open */
    document.addEventListener('keydown', function (e) {
      if (e.key !== 'Escape') return;
      if (successModal && !successModal.hidden) closeModal(successModal);
      if (errorModal && !errorModal.hidden) closeModal(errorModal);
    });
  })();


  /* ========================================================
     PART 3 — Gallery Lightbox, Reviews Slider, FAQ Accordion
     ======================================================== */

  /* --------------------------------------------------------
     9. GALLERY LIGHTBOX
     -------------------------------------------------------- */
  (function initLightbox() {
    var items     = qsa('.gallery__item');
    var lightbox  = qs('#lightbox');
    var backdrop  = qs('#lightboxBackdrop');
    var imgEl     = qs('#lightboxImg');
    var caption   = qs('#lightboxCaption');
    var closeBtn  = qs('#lightboxClose');
    var prevBtn   = qs('#lightboxPrev');
    var nextBtn   = qs('#lightboxNext');

    if (!items.length || !lightbox || !imgEl) return;

    var currentIndex = 0;
    var lastFocused  = null;

    /* Build a lookup of { src, alt } from the gallery DOM, in display order */
    var slides = items.map(function (item) {
      var img = item.querySelector('.gallery__img');
      return {
        src: img ? img.getAttribute('src') : '',
        alt: img ? img.getAttribute('alt') : ''
      };
    });

    function renderSlide(index) {
      var slide = slides[index];
      if (!slide) return;
      imgEl.src = slide.src;
      imgEl.alt = slide.alt;
      if (caption) caption.textContent = (index + 1) + ' / ' + slides.length;
    }

    function openLightbox(index) {
      currentIndex = index;
      lastFocused = document.activeElement;
      renderSlide(currentIndex);

      lightbox.hidden = false;
      lightbox.setAttribute('aria-hidden', 'false');
      document.body.style.overflow = 'hidden';

      if (closeBtn) closeBtn.focus();
    }

    function closeLightbox() {
      lightbox.hidden = true;
      lightbox.setAttribute('aria-hidden', 'true');
      document.body.style.overflow = '';
      imgEl.src = '';

      if (lastFocused && typeof lastFocused.focus === 'function') {
        lastFocused.focus();
      }
    }

    function showNext() {
      currentIndex = (currentIndex + 1) % slides.length;
      renderSlide(currentIndex);
    }

    function showPrev() {
      currentIndex = (currentIndex - 1 + slides.length) % slides.length;
      renderSlide(currentIndex);
    }

    /* Open on gallery item click */
    items.forEach(function (item, idx) {
      item.addEventListener('click', function () {
        openLightbox(idx);
      });
    });

    /* Controls */
    if (closeBtn) closeBtn.addEventListener('click', closeLightbox);
    if (backdrop) backdrop.addEventListener('click', closeLightbox);
    if (nextBtn)  nextBtn.addEventListener('click', showNext);
    if (prevBtn)  prevBtn.addEventListener('click', showPrev);

    /* Keyboard support: Escape, Arrow keys, Tab trap */
    document.addEventListener('keydown', function (e) {
      if (lightbox.hidden) return;

      if (e.key === 'Escape') {
        closeLightbox();
      } else if (e.key === 'ArrowRight') {
        showNext();
      } else if (e.key === 'ArrowLeft') {
        showPrev();
      } else if (e.key === 'Tab') {
        /* Simple focus trap among lightbox controls */
        var focusable = qsa(
          '.lightbox__close, .lightbox__arrow',
          lightbox
        ).filter(function (el) { return !el.disabled; });
        if (!focusable.length) return;

        var first = focusable[0];
        var last  = focusable[focusable.length - 1];

        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    });
  })();


  /* --------------------------------------------------------
     10. REVIEWS SLIDER — responsive, auto-play, manual arrows
     -------------------------------------------------------- */
  (function initReviewsSlider() {
    var wrap    = qs('.reviews__slider-wrap');
    var slider  = qs('#reviewsSlider');
    var prevBtn = qs('#reviewsPrev');
    var nextBtn = qs('#reviewsNext');
    var dotsBox = qs('#reviewsDots');

    if (!wrap || !slider || !slider.children.length) return;

    var cards = qsa('.review-card', slider);
    var currentPage = 0;
    var perPage = 3;
    var autoTimer = null;
    var AUTOPLAY_MS = 5000;

    function getPerPage() {
      var w = window.innerWidth;
      if (w <= 640) return 1;
      if (w <= 1024) return 2;
      return 3;
    }

    function totalPages() {
      return Math.max(1, Math.ceil(cards.length / perPage));
    }

    function buildDots() {
      if (!dotsBox) return;
      dotsBox.innerHTML = '';
      var pages = totalPages();
      for (var i = 0; i < pages; i++) {
        var dot = document.createElement('button');
        dot.className = 'reviews__dot' + (i === currentPage ? ' is-active' : '');
        dot.setAttribute('role', 'tab');
        dot.setAttribute('aria-label', 'Go to review page ' + (i + 1));
        dot.setAttribute('aria-selected', i === currentPage ? 'true' : 'false');
        dot.addEventListener('click', function (pageIndex) {
          return function () {
            goToPage(pageIndex);
            restartAutoplay();
          };
        }(i));
        dotsBox.appendChild(dot);
      }
    }

    function updateDots() {
      if (!dotsBox) return;
      qsa('.reviews__dot', dotsBox).forEach(function (dot, i) {
        dot.classList.toggle('is-active', i === currentPage);
        dot.setAttribute('aria-selected', i === currentPage ? 'true' : 'false');
      });
    }

    function updateArrowStates() {
      var pages = totalPages();
      if (prevBtn) prevBtn.disabled = pages <= 1;
      if (nextBtn) nextBtn.disabled = pages <= 1;
    }

    function goToPage(pageIndex) {
      var pages = totalPages();
      currentPage = ((pageIndex % pages) + pages) % pages;

      var cardWidth = cards[0] ? cards[0].getBoundingClientRect().width : 0;
      var gap = parseFloat(getComputedStyle(slider).gap || '0');
      var offset = currentPage * perPage * (cardWidth + gap);

      slider.style.transform = 'translateX(-' + offset + 'px)';
      updateDots();
    }

    function nextPage() { goToPage(currentPage + 1); }
    function prevPage() { goToPage(currentPage - 1); }

    function startAutoplay() {
      stopAutoplay();
      autoTimer = setInterval(nextPage, AUTOPLAY_MS);
    }

    function stopAutoplay() {
      if (autoTimer) {
        clearInterval(autoTimer);
        autoTimer = null;
      }
    }

    function restartAutoplay() {
      startAutoplay();
    }

    function recalcLayout() {
      var newPerPage = getPerPage();
      if (newPerPage !== perPage) {
        perPage = newPerPage;
        currentPage = 0;
        buildDots();
        updateArrowStates();
      }
      /* Re-apply transform with fresh measurements (handles resize too) */
      goToPage(currentPage);
    }

    /* Wire up controls */
    if (nextBtn) {
      nextBtn.addEventListener('click', function () {
        nextPage();
        restartAutoplay();
      });
    }
    if (prevBtn) {
      prevBtn.addEventListener('click', function () {
        prevPage();
        restartAutoplay();
      });
    }

    /* Pause autoplay on hover/focus, resume on leave */
    wrap.addEventListener('mouseenter', stopAutoplay);
    wrap.addEventListener('mouseleave', startAutoplay);
    wrap.addEventListener('focusin', stopAutoplay);
    wrap.addEventListener('focusout', startAutoplay);

    /* Recalculate on resize (throttled) */
    var resizeTicking = false;
    window.addEventListener('resize', function () {
      if (!resizeTicking) {
        window.requestAnimationFrame(function () {
          recalcLayout();
          resizeTicking = false;
        });
        resizeTicking = true;
      }
    });

    /* Init */
    perPage = getPerPage();
    buildDots();
    updateArrowStates();
    goToPage(0);
    startAutoplay();
  })();


  /* --------------------------------------------------------
     11. FAQ ACCORDION — single-open, animated, keyboard friendly
     -------------------------------------------------------- */
  (function initFaqAccordion() {
    var faqItems = qsa('.faq-item');
    if (!faqItems.length) return;

    function closeItem(item) {
      var trigger = item.querySelector('.faq-item__trigger');
      var panel   = item.querySelector('.faq-item__panel');
      if (!trigger || !panel) return;

      item.classList.remove('is-open');
      trigger.setAttribute('aria-expanded', 'false');
      panel.hidden = true;
    }

    function openItem(item) {
      var trigger = item.querySelector('.faq-item__trigger');
      var panel   = item.querySelector('.faq-item__panel');
      if (!trigger || !panel) return;

      item.classList.add('is-open');
      trigger.setAttribute('aria-expanded', 'true');
      panel.hidden = false;
    }

    faqItems.forEach(function (item) {
      var trigger = item.querySelector('.faq-item__trigger');
      if (!trigger) return;

      trigger.addEventListener('click', function () {
        var isOpen = item.classList.contains('is-open');

        /* Close all other items — only one open at a time */
        faqItems.forEach(function (other) {
          if (other !== item) closeItem(other);
        });

        if (isOpen) {
          closeItem(item);
        } else {
          openItem(item);
        }
      });

      /* Keyboard: Arrow Up/Down moves between triggers */
      trigger.addEventListener('keydown', function (e) {
        var triggers = qsa('.faq-item__trigger');
        var idx = triggers.indexOf(trigger);

        if (e.key === 'ArrowDown') {
          e.preventDefault();
          var next = triggers[(idx + 1) % triggers.length];
          if (next) next.focus();
        } else if (e.key === 'ArrowUp') {
          e.preventDefault();
          var prev = triggers[(idx - 1 + triggers.length) % triggers.length];
          if (prev) prev.focus();
        }
      });
    });
  })();


  /* ========================================================
     PART 4 — Contact Form, Floating Buttons, Sticky Mobile CTA
     ======================================================== */

  /* --------------------------------------------------------
     12. CONTACT FORM — validation & submission
     -------------------------------------------------------- */
  (function initContactForm() {
    var form       = qs('#contactForm');
    var submitBtn  = qs('#contactSubmitBtn');
    var successBox = qs('#contactSuccess');

    if (!form) return;

    var BD_PHONE_RE = /^(?:\+88)?01[3-9]\d{8}$/;

    var rules = {
      contactName:    { required: true, label: 'Name' },
      contactPhone:   { required: true, label: 'Phone', pattern: BD_PHONE_RE, patternMsg: 'Enter a valid Bangladeshi number (e.g. 01712345678)' },
      contactMessage: { required: true, label: 'Message' }
    };

    function showError(fieldId, msg) {
      var input = qs('#' + fieldId);
      var errEl = qs('#' + fieldId + '-err');
      if (!input || !errEl) return;
      input.classList.add('is-error');
      errEl.textContent = msg;
    }

    function clearError(fieldId) {
      var input = qs('#' + fieldId);
      var errEl = qs('#' + fieldId + '-err');
      if (!input || !errEl) return;
      input.classList.remove('is-error');
      errEl.textContent = '';
    }

    function validateField(fieldId) {
      var rule  = rules[fieldId];
      var input = qs('#' + fieldId);
      if (!rule || !input) return true;

      var val = input.value.trim();

      if (rule.required && !val) {
        showError(fieldId, rule.label + ' is required.');
        return false;
      }
      if (rule.pattern && val && !rule.pattern.test(val)) {
        showError(fieldId, rule.patternMsg || 'Invalid format.');
        return false;
      }
      clearError(fieldId);
      return true;
    }

    Object.keys(rules).forEach(function (id) {
      var input = qs('#' + id);
      if (!input) return;
      input.addEventListener('blur', function () { validateField(id); });
      input.addEventListener('input', function () {
        if (input.classList.contains('is-error')) clearError(id);
      });
    });

    form.addEventListener('submit', function (e) {
      e.preventDefault();

      var valid = true;
      Object.keys(rules).forEach(function (id) {
        if (!validateField(id)) valid = false;
      });

      if (!valid) {
        var firstErr = form.querySelector('.is-error');
        if (firstErr) firstErr.focus();
        return;
      }

      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.textContent = 'Sending…';
      }

      /* Simulate async submission (replace with real API call) */
      setTimeout(function () {
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.textContent = 'Submit';
        }
        if (successBox) {
          successBox.hidden = false;
          successBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
        form.reset();
      }, 900);
    });
  })();


  /* --------------------------------------------------------
     13. FLOATING BUTTONS — reveal on scroll, back to top
     -------------------------------------------------------- */
  (function initFloatingButtons() {
    var floatingWrap = qs('#floatingButtons');
    var backToTopBtn = qs('#backToTopBtn');

    if (!floatingWrap) return;

    var REVEAL_THRESHOLD   = 240; /* px scrolled before main buttons appear */
    var TOP_BTN_THRESHOLD  = 600; /* px scrolled before back-to-top appears */

    function handleScroll() {
      var scrolled = window.scrollY;

      floatingWrap.classList.toggle('is-visible', scrolled > REVEAL_THRESHOLD);

      if (backToTopBtn) {
        backToTopBtn.classList.toggle('is-shown', scrolled > TOP_BTN_THRESHOLD);
      }
    }

    var ticking = false;
    window.addEventListener('scroll', function () {
      if (!ticking) {
        window.requestAnimationFrame(function () {
          handleScroll();
          ticking = false;
        });
        ticking = true;
      }
    }, { passive: true });

    handleScroll();

    /* Back to top action */
    if (backToTopBtn) {
      backToTopBtn.addEventListener('click', function () {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      });
    }
  })();


  /* --------------------------------------------------------
     14. STICKY MOBILE CTA — reveal on scroll, scroll to order
     -------------------------------------------------------- */
  (function initStickyCta() {
    var stickyCta    = qs('#stickyCta');
    var stickyCtaBtn = qs('#stickyCtaBtn');
    var orderSection = qs('#order');

    if (!stickyCta) return;

    var REVEAL_AFTER = 320; /* px scrolled before sticky CTA appears */

    function handleScroll() {
      stickyCta.classList.toggle('is-visible', window.scrollY > REVEAL_AFTER);
    }

    var ticking = false;
    window.addEventListener('scroll', function () {
      if (!ticking) {
        window.requestAnimationFrame(function () {
          handleScroll();
          ticking = false;
        });
        ticking = true;
      }
    }, { passive: true });

    handleScroll();

    /* Pre-select the 5-piece package — this also scrolls to the order form */
    if (stickyCtaBtn) {
      stickyCtaBtn.addEventListener('click', function () {
        var fivePieceBtn = qs('.pkg-card[data-pkg-id="5"] .pkg-card__btn');
        if (fivePieceBtn) {
          fivePieceBtn.click();
        } else if (orderSection) {
          /* Fallback: just scroll if the card isn't found for some reason */
          var navbarH = parseInt(
            getComputedStyle(document.documentElement).getPropertyValue('--navbar-h') || '72',
            10
          );
          var top = orderSection.getBoundingClientRect().top + window.scrollY - navbarH - 24;
          window.scrollTo({ top: top, behavior: 'smooth' });
        }
      });
    }
  })();

})();
